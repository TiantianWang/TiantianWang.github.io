Due to implementation issue, the current code cannot handle very large images (out of memory error).
I used to test images with sizes under 800x600.   

Usage: Open two image files by click "File->open" in the menu. The matching results will be shown. 
The red line segments with the same lables at their middle points are corresponding line segments. 
Click "+" and "-" to zoom the images.

The matching result will be saved in "result.txt" that is usually located in the same folder of the images.
The format of "result.txt is as follows:

number of matches
x1 y1 x2 y2 x3 y3 x4 y4
.....
....
where x1 y1 x2 y2 are the two endpoints of the line segment in the first image
and x3 y3 x4 y4 are the two endpoints of th corresponding line segment in the second image