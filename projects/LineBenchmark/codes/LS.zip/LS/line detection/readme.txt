Usuage:
lineDetection input_image_name output_txt_name

For example:
lineDetection C:\input\1.jpg C:\output\line.txt

Each line segment is represented by its two endpoints (x1, y1) and (x2, y2)
The format of the output file:

number of line segments
x1 y1 x2 y2
x1 y1 x2 y2
.....
.....
..... 